package com.fitness.ai_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AiServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
